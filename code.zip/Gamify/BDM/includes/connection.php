<?php
    $connection=mysqli_connect('localhost','root','','gamify');
    if(!$connection){
    echo "Database connection failed";
    }
?>