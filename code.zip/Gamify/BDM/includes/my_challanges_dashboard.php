<?php
$query= "SELECT * FROM task WHERE task_status='in_progress'";
$status_query=mysqli_query($connection,$query);
while($row=mysqli_fetch_assoc($status_query)){
  $task_title=$row['task_title'];
  $task_deadline=$row['task_deadline'];
  $task_assignee=$row['task_assignee'];

?>
                  <tr>
                    <th ><?php echo $task_title?></th>
                    <th ><?php echo $task_deadline?></th>
                    <th >In progress</th>
                    
                  </tr>
<?php }?>