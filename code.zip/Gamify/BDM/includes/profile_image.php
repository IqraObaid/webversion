<?php
  $query="SELECT * FROM signin where username='$username'";
  $image_query=mysqli_query($connection,$query);
  $row=mysqli_fetch_assoc($image_query);
  $image=$row['image'];

?> 
 
 <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
      <div class="photo">
        <img src="../images/<?php echo $image?>" alt="Profile Photo">
      </div>
      <b class="caret d-none d-lg-block d-xl-block"></b>
      <p class="d-lg-none">
          Log out
      </p>
  </a>