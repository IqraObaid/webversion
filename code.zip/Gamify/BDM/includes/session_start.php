<?php
    session_start();
    $_SESSION['id']=$username;
?>
