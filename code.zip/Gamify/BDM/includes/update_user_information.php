<?php
  $query="SELECT * FROM signin where username='$username'";
  $edit_query=mysqli_query($connection,$query);
  $row=mysqli_fetch_assoc($edit_query);
  $name=$row['name'];
  $contact=$row['phone_number'];
  $email=$row['email'];
  $address=$row['address'];
  $image=$row['image'];

  if(isset($_POST['submit'])){
    $contact=$_POST['contact'];
    $email=$_POST['email'];
    $address=$_POST['address'];
    
    $image=$_FILES['image']['name'];
    $image_temp=$_FILES['image']['tmp_name'];
    move_uploaded_file($image_temp,"../images/$image");

    $query="UPDATE signin SET email='$email',phone_number='$contact',address='$address' ,image='$image'  where username='$username' ";
    $update_query=mysqli_query($connection,$query);
    if(!$update_query){
      echo "Query failed";
    }
  }

?>