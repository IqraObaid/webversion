<?php 
include '../includes/connection.php';
include '../includes/functions.php';
?>
<?php
session_start();
$username=$_SESSION['id'];
$userid=GetUserId($username);
 if(!$_SESSION['id']){
  include '../includes/session_destroy.php';
 }
if(isset($_POST['logout'])){
  include '../includes/session_destroy.php';
}
  

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <link rel="stylesheet" href="../asset/style.css">
  <title>
    Dashboard
  </title>
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,600,700,800" rel="stylesheet" />
  <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
  <!-- Nucleo Icons -->
  <link href="../assets/css/nucleo-icons.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="../assets/css/black-dashboard.css?v=1.0.0" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="../assets/demo/demo.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

  <script src="https://kit.fontawesome.com/1493114a02.js" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  
  <style>
    svg.radial-progress {
  height: auto;
  max-width: 180px;
  padding: 1em;
  transform: rotate(-90deg);
  width: 100%;
}

svg.radial-progress circle {
  fill: rgba(0,0,0,0);
  stroke: #fff;
  stroke-dashoffset: 219.91148575129; /* Circumference */
  stroke-width: 10;
}

svg.radial-progress circle.incomplete { opacity: 0.25; }

svg.radial-progress circle.complete { stroke-dasharray: 219.91148575129; /* Circumference */ }

svg.radial-progress text {
  fill: #fff;
  font: 400 1em/1 'Oswald', sans-serif;
  text-anchor: middle;
}

/*** COLORS ***/
/* Primary */

svg.radial-progress:nth-of-type(6n+1) circle { stroke: #83e4e2; }

/* Secondary */

svg.radial-progress:nth-of-type(6n+2) circle { stroke: #83e4e2; }

  </style>
 
</head>

<body class="">
  <div class="wrapper">
    <?php include '../includes/navigation_sidebar.php'?>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-absolute navbar-transparent">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <div class="navbar-toggle d-inline">
              <button type="button" class="navbar-toggler">
                <span class="navbar-toggler-bar bar1"></span>
                <span class="navbar-toggler-bar bar2"></span>
                <span class="navbar-toggler-bar bar3"></span>
              </button>
            </div>
            <a class="navbar-brand" href="javascript:void(0)">Dashboard</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
          </button>
          <div class="collapse navbar-collapse" id="navigation">
            <ul class="navbar-nav ml-auto">
              <li class="search-bar input-group">
                <?php include '../includes/search.php'?>
              </li>
              
              <li class="dropdown nav-item">
                <?php include '../includes/profile_image.php'?>
                  <?php include '../includes/profile_dropdown.php'?>
              </li>
              <li class="separator d-lg-none"></li>
            </ul>
          </div>
        </div>
      </nav>
      <div class="modal modal-search fade" id="searchModal" tabindex="-1" role="dialog" aria-labelledby="searchModal" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <input type="text" class="form-control" id="inlineFormInputGroup" placeholder="SEARCH">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <i class="tim-icons icon-simple-remove"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
      <!-- End Navbar -->
      <div class="content ">
        
        <div class="d-flex justify-content-center">

        <?php include '../includes/progress_bar.php'?>
        <div class="mt-4 row ">

          <div class="col-md-8">
            <div class="border p-2 rounded" style=" background-color: rgb(39,41,61); border-color: rgb(39,41,61) !important; ">
      
      
              <div class="mt-2 px-4">
                <span class="font-weight-bold" style="font-size: 20px ; color: rgb(248,255,255);">PROGRESS</span>
              </div>
              
              <div class="d-flex mt-2">
        
              
          
          <div class=" py-10 h-64 " style=" width: 33%;">
            <span class="d-flex justify-content-center text-xs" style="color: rgb(248,255,255);">Total Points</span>
            
            <div class="d-flex justify-content-center" style="border-right:2px rgb(248,255,255) solid; ">
             <?php
			// Assuming you have already established a database connection and retrieved the total marks from the database.
			$point = get_usertotal_points($userid);
			$totalMarks = ($point != 0) ? ((int)($point)) : 0;

			// Calculate the percentage of points achieved relative to 3000 points.
			$percentageToFill = ($totalMarks >= 3000) ? 100 : ((int)(($totalMarks * 100) / 3000));

			// Display 0 percentage if total marks are 0, otherwise show the calculated percentage.
			$displayPercentage = ($totalMarks !== 0) ? $percentageToFill : 0;
			?>

				<svg class="radial-progress mt-4" data-percentage="<?php echo $displayPercentage; ?>" viewBox="0 0 80 80">
				  <circle class="incomplete" cx="40" cy="40" r="35"></circle>
				  <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: <?php echo 35 - ($displayPercentage * 0.35); ?>;"></circle>
				  <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)"><?php echo $totalMarks; ?></text>
				</svg>
            </div>
            
              
          </div>
          <div class="  py-10 h-64 " style=" width: 33%;">
            <span class="d-flex justify-content-center text-xs" style="color: rgb(248,255,255);">Current Progress</span>
            <!-- <div class="d-flex justify-content-center">
              <div class="progress yellow progress1 yellow1"> <span class="progress-left progress-left1"> <span class="progress-bar progress-bar1"></span> </span> <span class="progress-right progress-right1"> <span class="progress-bar progress-bar1"></span> </span>
                <div class="progress-value progress-value1">37.5%</div>
            </div>
            </div> -->
			<div class="d-flex justify-content-center" style="border-right:2px rgb(248,255,255) solid; ">
			  <?php
			  $totalTaskPoints = total_task_points($userid);

			  // Assuming you have already established a database connection and retrieved the total marks from the database.
			  $totalMarks = get_usertotal_points($userid);

			  // Calculate the percentage of points achieved.
			  $percentage = ($totalTaskPoints != 0) ? ((int)(($totalMarks * 100) / $totalTaskPoints)) : 0;
			  ?>

			  <svg class="radial-progress mt-4 " data-percentage="<?php echo $percentage; ?>" viewBox="0 0 80 80">
				<circle class="incomplete" cx="40" cy="40" r="35"></circle>
				<circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: <?php echo 35 - ($percentage * 0.35 / 100); ?>;"></circle>
				<text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)"><?php echo $percentage; ?>%</text>
			  </svg>
			</div>


            <!--<div class="d-flex justify-content-center" style="border-right:2px rgb(248,255,255) solid; ">
              <svg class="radial-progress mt-4 " data-percentage="33" viewBox="0 0 80 80">
                <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset:32;"></circle>
                <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)"><?php if (total_task_points($userid)!=0) echo (int)((get_usertotal_points($userid)*100)/total_task_points($userid))?></text>
                </svg>
            </div>-->
            
          </div>
          <?php 
        $current_points=get_usertotal_points($userid);
              if($current_points<2000){
                  $badge="color: rgb(112,72,56);";
                  $badge_name='Bronze';
              }elseif($current_points>=2000 && $current_points<3000){
                $badge="color:rgb(133, 133, 133);";
                $badge_name='Silver';

              }else{
                  $badge="color: rgb(202, 177, 62)";
                  $badge_name='Gold';
              }
          ?>
          <div class="  py-10 h-64 " style="width: 33%;">
            <span class="d-flex justify-content-center text-xs" style="color: rgb(248,255,255);">Badges</span>
            <div class="m-10">
              <i class="fas fa-medal d-flex  justify-content-center  text-9xl radial-progress  " style=" <?php echo $badge?>"></i>
              <span class="d-flex justify-content-center mt-2" style="<?php echo $badge?>"><?php echo $badge_name?></span>
            
            </div>
           
          </div>
        </div>
        
        </div>
        <?php
  $query = "SELECT count(*) as total FROM task";
  $count_query = mysqli_query($connection, $query);
  $row = mysqli_fetch_assoc($count_query);
  $total = $row['total'];

  $query = "SELECT count(*) as total FROM task WHERE task_status='completed'";
  $count_query = mysqli_query($connection, $query);
  $row = mysqli_fetch_assoc($count_query);
  $total_completed = $row['total'];

  $query = "SELECT count(*) as total FROM task WHERE task_status='in_progress'";
  $count_query = mysqli_query($connection, $query);
  $row = mysqli_fetch_assoc($count_query);
  $total_inprogress = $row['total'];

  $query = "SELECT count(*) as total FROM task WHERE task_status='overdue'";
  $count_query = mysqli_query($connection, $query);
  $row = mysqli_fetch_assoc($count_query);
  $total_overdue = $row['total'];

  $show_progress = ($total > 0 || $total_completed > 0 || $total_inprogress > 0 || $total_overdue > 0);
?>

<div class="mt-4 p-2 rounded" style="background-color: rgb(39,41,61); border-color: rgb(39,41,61) !important;">
  <div class="mt-2 px-4">
    <span class="font-weight-bold" style="font-size: 20px; color: rgb(248,255,255);">Tasks</span>
  </div>
  <div class="d-flex justify-content-center mb-4">
    <div class="relative w-75 pt-1">
      <?php if ($show_progress): ?>
        <div class="progress mt-4" style="height: 40px;">
          <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo $total; ?>%" aria-valuenow="<?php echo $total; ?>" aria-valuemin="0" aria-valuemax="100"></div>
          <div class="progress-bar bg-info" role="progressbar" style="width: <?php echo $total_completed; ?>%" aria-valuenow="<?php echo $total_completed; ?>" aria-valuemin="0" aria-valuemax="100"></div>
          </div>
      <?php else: ?>
        <div class="progress mt-4" style="height: 40px;">
          <div class="progress-bar bg-secondary" role="progressbar" style="width: 100%" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
      <?php endif; ?>

      <div class="mt-4 d-flex align-items-center">
        <div class="rounded-circle bg-success" style="width: 20px; height: 20px;"></div>
        <span class="p-2">Completed</span>
      </div>
      <div class="mt-2 d-flex align-items-center">
        <div class="rounded-circle bg-info" style="width: 20px; height: 20px;"></div>
        <span class="p-2">In Progress</span>
      </div>
      <div class="mt-2 d-flex align-items-center">
        <div class="rounded-circle bg-warning" style="width: 20px; height: 20px;"></div>
        <span class="p-2">Overdue</span>
      </div>
    </div>
  </div>
</div>

        <!-- progress end -->
        <div class="shadow-lg rounded-lg overflow-hidden mt-4 p-2" style="background-color: rgb(39,41,61);">
          <div class="mt-2 px-4">
            <span class="font-weight-bold" style="font-size: 20px ; color: rgb(248,255,255);">Response Time</span>
          </div>
          <canvas class="p-4 " id="chartLine"></canvas>
        </div>
          </div>
<!-- col-8 end -->
          <div class="col-md-4">
           <!-- REMOVE <div class=" d-flex p-2  rounded w-100 justify-content-center" style="background-color: rgb(39,41,61);">
            <ul class="nav nav-tabs nav-bar-dark">
              <li class="  nav-item ">
                <a class="nav-link active" style="color: rgb(248,255,255)!important;" href="" >Today</a>
              </li>
              <!-- <li class=" nav-item"><a class="nav-link" style="color: rgb(248,255,255)!important;" href="">Yesterday</a></li> -->
              <!-- REMOVE <li class="nav-item" ><a class="nav-link" style="color: rgb(248,255,255)!important;" href="">Week</a></li>
              <li class=" nav-item"><a class="nav-link" style="color: rgb(248,255,255)!important;" href="">Month</a></li>
              <li class="nav-item"><a class="nav-link" style="color: rgb(248,255,255)!important;" href="">Year</a></li>
            </ul>
              
            </div> REMOVE-->
            <div class="mt-4  d-flex rounded w-100" style="background-color: rgb(39,41,61);">
              <div class="  p-2 mr-3 col-md rounded "  >
             
               
                <i class="fas fa-medal d-flex  justify-content-center  mt-4" style="font-size: 5rem;   color:rgb(112,72,56);"></i>
                <span class="d-flex justify-content-center mt-4 text-xs"  style="color:rgb(248,255,255) ;" >On achieving</span>
                <span class="d-flex justify-content-center mt-2 font-bold text-sm" style=" color:rgb(248,255,255) ;">1000 Points</span>
                
              </div>
              <div class="  py-8  col-md p-2 mr-3 rounded "  >
               
                <i class="fas fa-medal d-flex  justify-content-center mt-4" style="font-size: 5rem; color:rgb(133, 133, 133);"></i>
                <span class="d-flex justify-content-center mt-4 text-xs" style="color:rgb(248,255,255) ;" >On achieving</span>
                <span class="d-flex justify-content-center mt-2 font-bold text-sm" style=" color:rgb(248,255,255) ;">2000 Points</span>
                
              </div>
              <div class="  py-8 col-md p-2  rounded"  >
               
                <i class="fas fa-medal d-flex  justify-content-center mt-4" style="font-size: 5rem; color: rgb(202, 177, 62)"></i>
                <span class="d-flex justify-content-center mt-4 text-xs" style="color:rgb(248,255,255) ;">On achieving</span>
                <span class="d-flex justify-content-center mt-2 font-bold text-sm" style=" color:rgb(248,255,255) ;">3000 Points</span>
                
              </div>
              
            </div>
            <div class="mt-4 p-2 rounded " style=" background-color: rgb(39,41,61) ;">
              <div class="mt-2 px-4 rounded"  >
                <span class="font-weight-bold text-lg" style=" color: rgb(248,255,255) ;">Leaderboard</span>
              </div>
              <?php include '../includes/leaderboard_dashboard.php'?>

       

              
            <!--<div class="mt-4 p-2 rounded" style=" background-color :  rgb(39,41,61);">
              <div class="mt-2 px-4 rounded"  >
                <span class="font-weight-bold text-lg" style=" color: rgb(248,255,255) ;">My Challanges</span>
              </div>
              <div class="table-responsive-sm mt-2">
          
              
              <table class=" table">
                <thead style=" color: rgb(248,255,255) ;">
                  <tr>
                    <th scope="col">Task</th>
                    <th scope="col">Task Deadline</th>
                    <th scope="col">Status</th>
                  </tr>
                </thead>
                
                <tbody style=" color: rgb(248,255,255) ;">
<?php include '../includes/my_challanges_dashboard.php'?>
                </tbody>
                
              </table>
            </div>-->
             
              
              
              
             
          
            </div>
           
          </div>
          
        </div>
        
        
      </div>
      <!-- content div end -->
     
    </div>
  
    
  </div>

  
  
  <div class="fixed-plugin">
    <div class="dropdown show-dropdown">
      <a href="#" data-toggle="dropdown">
        <i class="fa fa-cog fa-2x"> </i>
      </a>
      <ul class="dropdown-menu">
        <li class="header-title"> Sidebar Background</li>
        <li class="adjustments-line">
          <a href="javascript:void(0)" class="switch-trigger background-color">
            <div class="badge-colors text-center">
              <span class="badge filter badge-primary active" data-color="primary"></span>
              <span class="badge filter badge-info" data-color="blue"></span>
              <span class="badge filter badge-success" data-color="green"></span>
             
            </div>
            <div class="clearfix"></div>
          </a>
        </li>
       <!-- <li class="adjustments-line text-center color-change">
          <span class="color-label">LIGHT MODE</span>
          <span class="badge light-badge mr-2"></span>
          <span class="badge dark-badge ml-2"></span>
          <span class="color-label">DARK MODE</span>
        </li>-->
      
      </ul>
    </div>
  </div>
  <!--   Core JS Files   -->
  <script src="../assets/js/core/jquery.min.js"></script>
  <script src="../assets/js/core/popper.min.js"></script>
  <script src="../assets/js/core/bootstrap.min.js"></script>
  <script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!--  Google Maps Plugin    -->
  <!-- Place this tag in your head or just before your close body tag. -->
  <script src="https://maps.googleapis.com/maps/api/js"></script>

  <!-- Chart JS -->
  <script src="../assets/js/plugins/chartjs.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="../assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Black Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="../assets/js/black-dashboard.min.js?v=1.0.0"></script><!-- Black Dashboard DEMO methods, don't include it in your project! -->
  <script src="../assets/demo/demo.js"></script>
  <script>
    $(document).ready(function() {
      $().ready(function() {
        $sidebar = $('.sidebar');
        $navbar = $('.navbar');
        $main_panel = $('.main-panel');

        $full_page = $('.full-page');

        $sidebar_responsive = $('body > .navbar-collapse');
        sidebar_mini_active = true;
        white_color = false;

        window_width = $(window).width();

        fixed_plugin_open = $('.sidebar .sidebar-wrapper .nav li.active a p').html();



        $('.fixed-plugin a').click(function(event) {
          if ($(this).hasClass('switch-trigger')) {
            if (event.stopPropagation) {
              event.stopPropagation();
            } else if (window.event) {
              window.event.cancelBubble = true;
            }
          }
        });

        $('.fixed-plugin .background-color span').click(function() {
          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data', new_color);
          }

          if ($main_panel.length != 0) {
            $main_panel.attr('data', new_color);
          }

          if ($full_page.length != 0) {
            $full_page.attr('filter-color', new_color);
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.attr('data', new_color);
          }
        });

        $('.switch-sidebar-mini input').on("switchChange.bootstrapSwitch", function() {
          var $btn = $(this);

          if (sidebar_mini_active == true) {
            $('body').removeClass('sidebar-mini');
            sidebar_mini_active = false;
            blackDashboard.showSidebarMessage('Sidebar mini deactivated...');
          } else {
            $('body').addClass('sidebar-mini');
            sidebar_mini_active = true;
            blackDashboard.showSidebarMessage('Sidebar mini activated...');
          }

          // we simulate the window Resize so the charts will get updated in realtime.
          var simulateWindowResize = setInterval(function() {
            window.dispatchEvent(new Event('resize'));
          }, 180);

          // we stop the simulation of Window Resize after the animations are completed
          setTimeout(function() {
            clearInterval(simulateWindowResize);
          }, 1000);
        });

        $('.switch-change-color input').on("switchChange.bootstrapSwitch", function() {
          var $btn = $(this);

          if (white_color == true) {

            $('body').addClass('change-background');
            setTimeout(function() {
              $('body').removeClass('change-background');
              $('body').removeClass('white-content');
            }, 900);
            white_color = false;
          } else {

            $('body').addClass('change-background');
            setTimeout(function() {
              $('body').removeClass('change-background');
              $('body').addClass('white-content');
            }, 900);

            white_color = true;
          }


        });

        $('.light-badge').click(function() {
          $('body').addClass('white-content');
        });

        $('.dark-badge').click(function() {
          $('body').removeClass('white-content');
        });
      });
    });
  </script>
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      demo.initDashboardPageCharts();

    });
  </script>
  <script src="https://cdn.trackjs.com/agent/v3/latest/t.js"></script>
  <script>
    window.TrackJS &&
      TrackJS.install({
        token: "ee6fab19c5a04ac1a32a645abde4613a",
        application: "black-dashboard-free"
      });
  </script>
  <script>

    const labels = [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
    ];
   
    const data = {
        labels: labels,
        
        datasets: [{
            label: '',
            // backgroundColor: 'hsl(252, 82.9%, 67.8%)',
            borderColor: 'hsl(252, 82.9%, 67.8%)',
            data: [0, 10, 5, 2, 20, 30, 45],
            labelcolor: 'rgb(248,255,255);'
        }]
    };

    const configLineChart = {
        type: 'line',
        data,
        options: {}
    };

    var chartLine = new Chart(
        document.getElementById('chartLine'),
        configLineChart
    );
</script>
<script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha384-tsQFqpEReu7ZLhBV2VZlAu7zcOV+rXbYlF2cqB8txI/8aZajjp4Bqd+V6D5IgvKT" crossorigin="anonymous"></script> 
<script>
$(function(){

    // Remove svg.radial-progress .complete inline styling
    $('svg.radial-progress').each(function( index, value ) { 
        $(this).find($('circle.complete')).removeAttr( 'style' );
    });

    // Activate progress animation on scroll
    $(window).scroll(function(){
        $('svg.radial-progress').each(function( index, value ) { 
            // If svg.radial-progress is approximately 25% vertically into the window when scrolling from the top or the bottom
            if ( 
                $(window).scrollTop() > $(this).offset().top - ($(window).height() * 0.75) &&
                $(window).scrollTop() < $(this).offset().top + $(this).height() - ($(window).height() * 0.25)
            ) {
                // Get percentage of progress
                percent = $(value).data('percentage');
                // Get radius of the svg's circle.complete
                radius = $(this).find($('circle.complete')).attr('r');
                // Get circumference (2πr)
                circumference = 2 * Math.PI * radius;
                // Get stroke-dashoffset value based on the percentage of the circumference
                strokeDashOffset = circumference - ((percent * circumference) / 100);
                // Transition progress for 1.25 seconds
                $(this).find($('circle.complete')).animate({'stroke-dashoffset': strokeDashOffset}, 1250);
            }
        });
    }).trigger('scroll');

});
</script>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</body>

</html>