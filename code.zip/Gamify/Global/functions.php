<?php
function get_counter($task_deadline){
$waiting_day=strtotime($task_deadline);
  $time_left = $waiting_day - time();

   $days = floor($time_left / (60*60*24));
   
   $time_left %= (60 * 60 * 24);

   $hours = floor($time_left / (60 * 60));
   $time_left %= (60 * 60);

   $min = floor($time_left / 60);
   $time_left %= 60;

   $sec = $time_left;

   $countdown=" $days $hours:$min:$sec ";
   
return $countdown;
}

function alert($task_deadline){
  $waiting_day=strtotime($task_deadline);
  $waiting_day=strtotime($task_deadline);
  $time_left = $waiting_day - time();
   $hours = floor($time_left / (60 * 60)); 
  if($hours==10)
{
 
  echo '<script>alert("hello")</script>';
    
  
}

}
function CurrentPoints($username){
  GLOBAL $connection;
  $query="SELECT * FROM signin WHERE username='$username'";
  $current_point_query=mysqli_query($connection,$query);
  $row=mysqli_fetch_assoc($current_point_query);
  $current_points=$row['total_points'];
  return $current_points;
  }
 ?>
 