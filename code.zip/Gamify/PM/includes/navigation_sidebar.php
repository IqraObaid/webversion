<div class="sidebar">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red"
      -->
      <div class="sidebar-wrapper">
        <div class="logo">
          <a href="javascript:void(0)" class="simple-text logo-mini">
            G
          </a>
          <a href="javascript:void(0)" class="simple-text logo-normal">
            GAMIFY
          </a>
        </div>
        <ul class="nav">
          <li class="active ">
            <a href="dashboard.php">
              <i class="fas fa-home"></i>
              <p>Home</p>
            </a>
          </li>
          <li>
            <a href="workshops.php">
              <i class="fas fa-tasks"></i>
              <p>Workshops</p>
            </a>
          </li>
          <li>
            <a href="projects.php">
              <i class="fas fa-tasks"></i>
              <p>Projects</p>
            </a>
          </li>
          <li>
            <a href="create_sub_projects.php">
              <i class="fas fa-tasks"></i>
              <p>Add Sub Project</p>
            </a>
          </li>
          <li>
            <a href="sub_project_assignment.php">
              <i class="fas fa-tasks"></i>
              <p>Sub Project Assignment</p>
            </a>
          </li>
          <li>
            <a href="rating.php">
              <i class="fas fa-tasks"></i>
              <p>Rating </p>
            </a>
          </li>
          <li>
            <a href="Task-Summary.php">
              <i class="fas fa-user-circle"></i>
              <p>Task</p>
            </a>
          </li>
          <li>
            <a href="tl_status.php">
              <i class="fas fa-user-circle"></i>
              <p>teamLead Status</p>
            </a>
          </li>
         
        </ul>
      </div>
    </div>