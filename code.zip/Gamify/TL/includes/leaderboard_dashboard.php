<?php
$query="SELECT username,image,total_points,id
FROM signin 
ORDER BY total_points DESC;";
$leader_board_query=mysqli_query($connection,$query);
$names_array=[];
$total_points_array=[];
$images=[];
$user_id=[];
$user_name=[];
$position=[];
$count=1;

while($row=mysqli_fetch_assoc($leader_board_query)){
  array_push($total_points_array,$row['total_points']);
  array_push($images,$row['image']);
  array_push($user_id,$row['id']);
  array_push($user_name,$row['username']);
  array_push($position,$count);
  $count++;
}
$array_length=count($user_id);
$currentuser_id;
$currentuser_points;
$curruntuser_images;
$curruntuser_names;


 for($i=0;$i<$array_length;$i++)
{
  if($user_id[$i]==$userid)
  {
    $currentuser_index=$i;
    $currentuser_points=$total_points_array[$i];
    $curruntuser_images=$images[$i];
    $currentuser_names=$user_name[$i];
  } 
 }
$count=0;
$Leadership_points=[];
$Leadership_ids=[];
$Leadership_images=[];
$Leadership_names=[];
$Leadership_position=[];
 for($i=$currentuser_index-1;$i>=0;$i--)
 {
 //echo $total_points_array[$i]."<br>";
  array_push($Leadership_ids,$user_id[$i]);
  array_push($Leadership_points,$total_points_array[$i]);
  array_push($Leadership_images,$images[$i]);
  array_push($Leadership_names,$user_name[$i]);
  array_push($Leadership_position,$position[$i]);
  // echo $total_points_array[$i]."<br>";
  // echo $user_id[$i]."<br>";

  $count++;
  //echo $count;
if($count==3)
{
  break;
}
 }

 array_push($Leadership_ids,$userid);
 array_push($Leadership_points,$currentuser_points);
 array_push($Leadership_images,$curruntuser_images);
 array_push($Leadership_names,$currentuser_names);
 $currentuser_id=count($Leadership_points)-1;

 $count=0;
 for($i=$currentuser_index+1;$i<$array_length; $i++)
 {
 // echo $total_points_array[$i]."<br>";
 array_push($Leadership_ids,$user_id[$i]); 
 array_push($Leadership_points,$total_points_array[$i]);
 array_push($Leadership_images,$images[$i]);
 array_push($Leadership_names,$user_name[$i]);
 array_push($Leadership_position,$position[$i]);
//  echo $total_points_array[$i]."<br>";
  // echo $user_id[$i]."<br>";

 $count++;
 //echo $count;
if($count==3)
{
  break; 
}
}
 
 
   for($i=0;$i<count($Leadership_points);$i++){
     $val = $Leadership_points[$i];
     $val1=$Leadership_ids[$i];
     $val2=$Leadership_names[$i];
     $val3=$Leadership_images[$i];

     $j = $i-1;
     while($j>=0 && $Leadership_points[$j] > $val){
       $Leadership_points[$j+1] = $Leadership_points[$j];
       $Leadership_ids[$j+1] = $Leadership_ids[$j];
       $Leadership_names[$j+1] = $Leadership_names[$j];
       $Leadership_images[$j+1] = $Leadership_images[$j];

       $j--;
     }
     $Leadership_points[$j+1] = $val;
     $Leadership_ids[$j+1] = $val1;
     $Leadership_names[$j+1] = $val2;
     $Leadership_images[$j+1] = $val3;
    //  echo $val."<br>";
   }
  // for($i=0;$i<count($Leadership_points);$i++){
  //   echo $Leadership_points[$i]." ".$Leadership_ids[$i]." ".$Leadership_names[$i]." ".$Leadership_images[$i]."<br>";

  // }
 

 $colours=['bg-primary','bg-warning','bg-dark','bg-success','bg-secondary','bg-danger','bg-light'];
 $position=['7th','6th','5th','4th','3rd','2nd','1st'];
$red='bg-warning';

for($i=count($Leadership_ids)-1;$i>=0;$i--){                
  ?>
  
                 <div class=" ">
                  <div class="mt-2 d-flex ">
                    <img class="w-10 h-10 object-cover rounded-full" src="../images/<?php echo $Leadership_images[$i]?>" alt="">
                    <span class="p-2" style=" color: rgb(248,255,255) ;"><?php echo $Leadership_names[$i]."Level(".($Leadership_points[$i]/1000).")"?></span>
                  </div>
                  <div class="text-right">
                    <span style=" color: rgb(248,255,255) ;" class="text-xs font-semibold inline-block text-success">
                      <?php 
                      if($Leadership_ids[$i]==$userid){
                        echo "YOU";
                      }else{
                        echo $position[$i];
                      }
                      ?>
                    </span>
                  </div>
               
                <div class="overflow-hidden h-2 mb-2 text-xs flex rounded bg-white">
                  <div style="width:<?php echo (($Leadership_points[$i]%1000)*100)/1000 ?>%"
                    class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center <?php echo $colours[$i]?>">
                  </div>
                </div>
                </div>
                <?php } 
  
?>
