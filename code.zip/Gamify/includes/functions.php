 
<?php
//select deadline from tasks where user_id =this AND status=not yet started OR IN_progress
function GetUsename($id){
    GLOBAL $connection;
    $query="SELECT username FROM signin WHERE id='$id'";
    $id_query=mysqli_query($connection,$query);
    $row=mysqli_fetch_assoc($id_query);
    return $row['username'];
}

function getdeadline($user_id){
    GLOBAL $connection;
    $query="SELECT task_id,task_deadline,task_title FROM task  WHERE task_assigned_to='$user_id' 
    AND task_status='not_started ' OR task_status='remaining' AND reminder=0  ";
    $getdeadline=mysqli_query($connection,$query);
    while($row=mysqli_fetch_assoc($getdeadline))
{
    $task_deadline=$row['task_deadline'];
    $task_title=$row['task_title'];
    $task_id=$row['task_id'];
    $waiting_day=strtotime($task_deadline);
    $waiting_day=strtotime($task_deadline);
    $time_left = $waiting_day - time();
     $hours = floor($time_left / (60 * 60)); 
    if($hours<=10)
  {
    echo "<script type='text/javascript'>alert('1 hour left for {$task_title} task');</script>";

  //update table name set reminder =1 where task id = $task_id
    $query = "UPDATE task SET reminder = 1 WHERE task_id = $task_id" ;
    GLOBAL $connection;
    $reminder=mysqli_query($connection,$query);
}        
}
}
function AllWorkShop(){
    GLOBAL $connection;
    $query="SELECT * FROM workshop";
    $workshop_query=mysqli_query($connection,$query);
    return $workshop_query;
}


function CurrentProgress($username){
    GLOBAL $connection;
    $query="SELECT * FROM signin WHERE username='$username'";
    $current_point_progress=mysqli_query($connection,$query);
    $row=mysqli_fetch_assoc($current_point_progress);
    $current_progress=$row['current_progress'];
    return $current_progress;

}
function BadgesEarned($username){
    GLOBAL $connection;
    $query="SELECT * FROM signin WHERE username='$username'";
    $current_point_progress=mysqli_query($connection,$query);
    $row=mysqli_fetch_assoc($current_point_progress);
    $badges_earned=$row['badges_earned'];
    return $badges_earned;

}
function GetUserId($username){
    GLOBAL $connection;
    $query="SELECT id FROM signin WHERE username='$username'";
    $id_query=mysqli_query($connection,$query);
    $row=mysqli_fetch_assoc($id_query);
    return $row['id'];
}

function Bonus(){
    GLOBAL $connection;
    $query="SELECT * FROM reward";
    $reward_query=mysqli_query($connection,$query);
    return $reward_query;
}
function get_usertotal_points($user_id)
{
    GLOBAL $connection;
   $query="SELECT SUM(task_points) AS total_points,s.id
FROM task t,signin s 
WHERE s.id=t.task_assigned_to
AND t.task_assigned_to = $user_id
AND t.task_status='completed'";
$reward=mysqli_query($connection,$query);
$row=mysqli_fetch_assoc($reward);
    return $row['total_points'];

}

function redeem_reward($user_id,$id){
    GLOBAL $connection;
    $query="INSERT INTO user_reward (user_id,reward_id) VALUES ($user_id,$id);";
    $reward_query=mysqli_query($connection,$query);
    if(!$reward_query){
        return false;
    }else{
        return true;
    }
}

function get_reward_id($user_id,$id)
{
GLOBAL $connection;
$query="SELECT user_id,reward_id 
FROM user_reward
WHERE user_id= $user_id AND reward_id=$id";
 $reward_query=mysqli_query($connection,$query);
 $row=mysqli_fetch_assoc($reward_query);
 if(!$row){
     return 0;
 }else{
     return 1;
 }

}
function total_task_points($user_id){
    GLOBAL $connection;
    $query="select sum(task_points) AS task_total_points
    from task
    where task_assigned_to=$user_id";
    $reward_query=mysqli_query($connection,$query);
    $row=mysqli_fetch_assoc($reward_query);
    return $row['task_total_points'];


}

?>