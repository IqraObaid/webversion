<head>
  <!-- Your other head elements (meta tags, title, etc.) -->

  <style>
    .sidebar {
      width: 280px; /* Adjust the width as needed */
    }

    .sidebar .nav li a {
      font-size: 20px; /* Adjust the font size as needed */
      font-weight: bold;
    }
  </style>
</head>
<body>
<div class="sidebar">

      <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red"
      -->
      <div class="sidebar-wrapper">
        <div class="logo">
          <a href="javascript:void(0)" class="simple-text logo-mini">
            G
          </a>
          <a href="javascript:void(0)" class="simple-text logo-normal">
            GAMIFY
          </a>
        </div>
        <ul class="nav">
          <li class="active ">
            <a href="dashboard.php">
              <i class="fas fa-home"></i>
              <p>Home</p>
            </a>
          </li>
          <li>
            <a href="workshops.php">
              <i class="fas fa-tasks"></i>
              <p>Workshops</p>
            </a>
          </li>
          <li>
            <a href="Tasks-Summary.php">
              <i class="fas fa-tasks"></i>
              <p>Tasks</p>
            </a>
          </li>
          <li>
            <a href="Leaderboards.php">
              <i class="fas fa-bullhorn"></i>
              <p>Leadership Board</p>
            </a>
          </li>
          <li>
            <a href="Score.php">
              <i class="fas fa-chart-bar"></i>
              <p>Your Score</p>
            </a>
          </li>
          <li>
          <li>
            <a href="Rewards.php">
            <i class="fas fa-bullhorn"></i>
              <p>Rewards</p>
            </a>
          </li>
         
        </ul>
      </div>
    </div>
	</body>