<ul class="dropdown-menu dropdown-navbar">
                  <li class="nav-link"><a href="General-Settings.php" class="nav-item dropdown-item">Profile</a></li>
                  <li class="dropdown-divider"></li>
                  <li class="nav-link">
                    <form action="" method='post'>
                    <input type="submit" class="nav-item dropdown-item" name="logout" value="logout">
                    </form>
                  </li>
                </ul>
