-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 20, 2023 at 04:09 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gamify`
--

-- --------------------------------------------------------

--
-- Table structure for table `hiring_task`
--

CREATE TABLE `hiring_task` (
  `hiring_task_id` int(11) NOT NULL,
  `hiring_task_description` varchar(255) NOT NULL,
  `task_assigned_to` int(11) NOT NULL,
  `task_assigned_by` int(11) NOT NULL,
  `task_status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hiring_task`
--

INSERT INTO `hiring_task` (`hiring_task_id`, `hiring_task_description`, `task_assigned_to`, `task_assigned_by`, `task_status`) VALUES
(1, '3 Web Developers ', 10, 1, 'inprogress'),
(2, 'dsfsdfsdf', 11, 19, 'completed'),
(3, 'sdfsdfsdfs', 10, 19, 'review'),
(4, 'sd', 0, 1, 'review'),
(5, 'adsadsas', 0, 1, 'completed'),
(6, 'adsadsas', 0, 1, 'inprogress'),
(7, 'asdsda', 10, 1, 'completed'),
(8, 'DBA', 10, 19, 'not_started_yet');

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `project_id` int(255) NOT NULL,
  `project_title` varchar(255) NOT NULL,
  `project_deadline` date NOT NULL,
  `project_points` int(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `project_assignee` int(11) NOT NULL,
  `project_assigned_to` int(11) NOT NULL,
  `project_description` varchar(255) NOT NULL,
  `project_started` date DEFAULT NULL,
  `project_completed` date DEFAULT NULL,
  `project_completion` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`project_id`, `project_title`, `project_deadline`, `project_points`, `status`, `project_assignee`, `project_assigned_to`, `project_description`, `project_started`, `project_completed`, `project_completion`) VALUES
(3, 'This is project 1', '2022-10-05', 2500, 'completed', 1, 20, '', '2021-09-10', '2021-09-15', 100),
(4, 'This is project 2', '2021-09-06', 1000, 'inprogress', 1, 20, '', '2021-09-15', '2021-10-09', 100),
(5, 'This is web development project', '2021-09-06', 3000, 'review', 1, 20, '', '2021-09-10', '2021-09-15', 100),
(6, '', '0000-00-00', 0, 'review', 1, 20, '', '2021-09-10', '2021-09-15', 100),
(7, 'asddas', '2021-10-07', 1230, 'overdue', 1, 20, 'asdasdas', '2021-09-10', '2021-09-15', 100),
(8, 'This is a project', '2021-10-10', 100, 'review', 9, 20, 'Mobile App,Website', NULL, NULL, 0),
(9, 'fsdfsdfsd', '2021-10-13', 100, 'not_started', 19, 20, 'sdfsdfsdfsdf', NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `reward`
--

CREATE TABLE `reward` (
  `id` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `points` int(11) NOT NULL,
  `reward` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reward`
--

INSERT INTO `reward` (`id`, `level`, `points`, `reward`, `comments`) VALUES
(1, 1, 1000, 'good', 'hello'),
(2, 2, 2000, '15000 RS', 'Good work'),
(3, 3, 3000, '20000 RS', 'Excellent Work'),
(4, 4, 4000, '25000 RS', 'Nice work'),
(5, 5, 5000, '30000 RS', 'Bravo ');

-- --------------------------------------------------------

--
-- Table structure for table `signin`
--

CREATE TABLE `signin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `current_progress` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` bigint(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `badges_earned` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `response_time` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `team` int(11) NOT NULL,
  `total_points` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `signin`
--

INSERT INTO `signin` (`id`, `username`, `password`, `role`, `current_progress`, `name`, `email`, `phone_number`, `address`, `badges_earned`, `image`, `response_time`, `rating`, `team`, `total_points`) VALUES
(1, 'Hannan97', '11111111', 'developer', 45, 'Hannan Bin Tahir', 'hannanbintahir@gmail.com', 3006444692, '', 10, 'OIP.jfif', 500, 5, 5, 4580),
(2, 'hannan', '11111111', 'developer', 70, 'Hannan Bin Tahir', 'hannanbintahir@gmail.com', 3006444692, 'Punjab society', 5, 'OIP.jfif', 600, 0, 1, 840),
(3, 'Ali123', '11111111', 'developer', 60, 'Ali Aslam', 'test1@test.com', 32112312231, 'Wapda Town Lahore', 6, 'OIP.jfif', 700, 0, 4, 840),
(4, 'abdr123', '11111111', 'developer', 43, 'Abdur Rehman', 'asd@asd.com', 3249933847, 'Askari 11', 0, 'OIP.jfif', 200, 0, 3, 5190),
(5, 'Aslam123', '11111111', 'developer', 80, 'Aslam Baig', 'asd@asd.com', 439933020, 'Not Available', 4, 'OIP.jfif', 450, 0, 1, 840),
(6, 'hannan123', '11111111', 'developer', 23, 'Hannan Bin Tahir', 'hannanbintahir@gmail.com', 3006444692, 'Punjab society', 5, 'OIP.jfif', 600, 0, 3, 1140),
(7, 'asdasd', '', 'project_manager', 0, 'adsasd', 'hannanbintahir@gmail.com', 3342234, 'sdfdsfsfd', 0, 'OIP.jfif', 0, 0, 0, 840),
(8, 'test1', '11111111', 'team_lead', 0, 'test', 'hannanbintahir@gmail.com', 3324234, 'asdasdsda', 0, 'OIP.jfif', 0, 3, 0, 359308),
(9, 'sdfsdfsdfsdf', '11111111', 'BDM', 0, 'sdffsddsf', 'hannanbintahir@gmail.com', 32442334, 'asdasdsda', 0, 'OIP.jfif\r\n', 0, 0, 0, 840),
(10, 'test2', '11111111', 'HR', 0, 'test2', 'test@test.com', 99090909342, 'asdasdasdsd', 0, 'OIP.jfif', 0, 0, 0, 840),
(11, 'test3', '11111111', 'HR', 0, 'test3', 'hannanbintahir@gmail.com', 4434343434, 'asdasdsda', 0, 'OIP.jfif', 0, 0, 0, 840),
(12, 'test4', '11111111', 'project_manager', 0, 'test4', 'hannanbintahir@gmail.com', 32423234234, 'asdasdsda', 0, 'OIP.jfif', 0, 0, 0, 840),
(13, 'test5', '1231312312312', 'project_manager', 0, 'test5', 'hannanbintahir@gmail.com', 32423234234, 'asdasdsda', 0, 'OIP.jfif', 0, 0, 0, 840),
(19, 'ceo123', '11111111', 'CEO', 0, 'ceo', 'ceo@test.com', 0, 'sdfsdfsdffsdf', 0, 'OIP.jfif', 0, 0, 0, 840),
(20, 'test6', '11111111', 'project_manager', 50, 'test6', 'test6@test.com', 324234234, 'sadasasdsd', 0, 'OIP.jfif', 0, 5, 0, 3340);

-- --------------------------------------------------------

--
-- Table structure for table `sub_project`
--

CREATE TABLE `sub_project` (
  `sub_project_id` int(11) NOT NULL,
  `sub_project_title` varchar(255) NOT NULL,
  `sub_project_deadline` date NOT NULL,
  `sub_project_points` int(255) NOT NULL,
  `sub_project_assignee` int(11) NOT NULL,
  `sub_project_assigned_to` int(11) NOT NULL,
  `sub_project_description` varchar(255) NOT NULL,
  `sub_project_status` varchar(255) NOT NULL,
  `sub_project_started` date NOT NULL,
  `sub_project_completed` date NOT NULL,
  `project_id` int(11) NOT NULL,
  `sub_project_completion` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sub_project`
--

INSERT INTO `sub_project` (`sub_project_id`, `sub_project_title`, `sub_project_deadline`, `sub_project_points`, `sub_project_assignee`, `sub_project_assigned_to`, `sub_project_description`, `sub_project_status`, `sub_project_started`, `sub_project_completed`, `project_id`, `sub_project_completion`) VALUES
(1, 'sdfdsdfs', '2021-10-09', 34234, 20, 8, 'sdfsfddfsfd', 'completed', '0000-00-00', '0000-00-00', 4, 0),
(2, 'sdf', '2021-10-02', 32342, 20, 8, '234234dsf', 'review', '2021-10-08', '2021-10-14', 4, 32),
(3, 'dfsdfd', '0000-00-00', 324234, 20, 8, 'sdfsdf', 'completed', '0000-00-00', '0000-00-00', 4, 0),
(4, 'fsdgs', '0000-00-00', 132412, 20, 8, 'gsddsdgad', 'review', '0000-00-00', '0000-00-00', 4, 0),
(5, 'fsdfsgs', '0000-00-00', 1231, 20, 8, 'fsdgsdfwefa', 'not_started_yet', '0000-00-00', '0000-00-00', 4, 32);

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

CREATE TABLE `task` (
  `task_id` int(11) NOT NULL,
  `task_title` varchar(255) NOT NULL,
  `task_deadline` date NOT NULL,
  `task_points` int(255) NOT NULL,
  `task_assignee` int(255) NOT NULL,
  `task_description` varchar(255) NOT NULL,
  `task_status` varchar(255) NOT NULL,
  `task_started` date DEFAULT NULL,
  `task_completed` date DEFAULT NULL,
  `task_completion` int(11) NOT NULL,
  `task_assigned_to` int(11) NOT NULL,
  `sub_project_id` int(11) NOT NULL,
  `reminder` int(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `task`
--

INSERT INTO `task` (`task_id`, `task_title`, `task_deadline`, `task_points`, `task_assignee`, `task_description`, `task_status`, `task_started`, `task_completed`, `task_completion`, `task_assigned_to`, `sub_project_id`, `reminder`) VALUES
(1, 'Database', '2022-08-31', 340, 8, '', 'inprogress', '2021-10-16', '2021-10-15', 33, 1, 0, 1),
(2, 'Website', '2022-10-08', 450, 8, '', 'completed', '2021-09-01', '2022-09-08', 30, 1, 0, 0),
(3, 'Backend', '2021-09-08', 3000, 8, '', 'completed', '2021-09-01', '2021-09-05', 100, 1, 0, 0),
(4, 'UI/UX', '2022-09-23', 600, 8, '', 'in progress', '2021-12-22', '2022-09-15', 0, 1, 0, 0),
(5, 'asddassd', '2021-09-01', 870, 8, 'sadsdasad', 'completed', '2021-09-03', '2021-09-12', 100, 4, 0, 0),
(6, 'asddsad', '2021-10-08', 233, 8, 'asds', 'completed', '0000-00-00', '0000-00-00', 0, 5, 2, 0),
(7, 'GUI Java', '2022-08-31', 300, 8, 'GUI for ticketing system', 'completed', '2021-10-21', '2021-10-21', 100, 6, 3, 0),
(9, 'DBMS', '2022-09-30', 1000, 8, 'hello', 'completed', '2022-09-04', '2022-09-24', 100, 3, 0, 0),
(10, 'ORACAL', '2022-09-30', 100, 8, 'asas', 'completed', '2022-09-03', '2022-09-29', 100, 7, 3, 0),
(11, 'FRONTEND', '2022-09-29', 170, 8, 'ggs', 'completed', '2022-09-05', '2022-09-27', 50, 1, 0, 0),
(12, 'Backend', '2022-09-28', 180, 8, 'afa', 'completed', '2022-09-04', '2022-09-24', 100, 9, 2, 0),
(13, 'GUI java', '2022-09-27', 120, 8, 'afsa', 'completed', '2022-09-05', '2022-09-23', 60, 10, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE `team` (
  `team_id` int(11) NOT NULL,
  `team_name` varchar(255) NOT NULL,
  `team_lead_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `team`
--

INSERT INTO `team` (`team_id`, `team_name`, `team_lead_id`) VALUES
(1, 'team 1', 1),
(2, 'team 2', 1),
(3, 'team 3', 1),
(4, 'hasdsa', 8),
(5, 'team1', 12);

-- --------------------------------------------------------

--
-- Table structure for table `user_reviews`
--

CREATE TABLE `user_reviews` (
  `id` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `current_progress` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_reward`
--

CREATE TABLE `user_reward` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `reward_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_reward`
--

INSERT INTO `user_reward` (`id`, `user_id`, `reward_id`) VALUES
(13, 1, 1),
(14, 1, 2),
(15, 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `workshop`
--

CREATE TABLE `workshop` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `assignee` int(11) NOT NULL,
  `date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `venue` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `workshop`
--

INSERT INTO `workshop` (`id`, `title`, `assignee`, `date`, `start_time`, `end_time`, `venue`, `link`, `type`) VALUES
(6, 'sdfsdfsdf', 1, '2021-12-08', '07:37:00', '07:37:00', '', 'sdfsdfsdff', 'online'),
(7, 'qweqweqwe', 1, '2021-12-04', '07:37:00', '07:37:00', 'qweqweeq', '', 'physical');

-- --------------------------------------------------------

--
-- Table structure for table `workshop_mcqs`
--

CREATE TABLE `workshop_mcqs` (
  `id` int(11) NOT NULL,
  `question` varchar(255) NOT NULL,
  `option1` varchar(255) NOT NULL,
  `option2` varchar(255) NOT NULL,
  `option3` varchar(255) NOT NULL,
  `option4` varchar(255) NOT NULL,
  `correct` varchar(255) NOT NULL,
  `workshop_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `workshop_mcqs`
--

INSERT INTO `workshop_mcqs` (`id`, `question`, `option1`, `option2`, `option3`, `option4`, `correct`, `workshop_id`) VALUES
(4, 'sadasd', 'dasasd', 'dfdf', 'fdgf', 'fgfg', 'dasasd', 6),
(5, 'What is a computer', 'device', 'machine', 'nothing', 'dont know', 'device', 6),
(10, 'asdsadd', 'asd', 'aaa', 'sss', 'dddd', 'asd', 6);

-- --------------------------------------------------------

--
-- Table structure for table `workshop_results`
--

CREATE TABLE `workshop_results` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `workshop_id` int(11) NOT NULL,
  `correct` int(11) NOT NULL,
  `percentage` int(11) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `workshop_results`
--

INSERT INTO `workshop_results` (`id`, `user_id`, `workshop_id`, `correct`, `percentage`, `status`) VALUES
(2, 1, 6, 2, 67, 'Attended');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hiring_task`
--
ALTER TABLE `hiring_task`
  ADD PRIMARY KEY (`hiring_task_id`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`project_id`);

--
-- Indexes for table `reward`
--
ALTER TABLE `reward`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signin`
--
ALTER TABLE `signin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sub_project`
--
ALTER TABLE `sub_project`
  ADD PRIMARY KEY (`sub_project_id`);

--
-- Indexes for table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`task_id`);

--
-- Indexes for table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`team_id`);

--
-- Indexes for table `user_reviews`
--
ALTER TABLE `user_reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_reward`
--
ALTER TABLE `user_reward`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `workshop`
--
ALTER TABLE `workshop`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `workshop_mcqs`
--
ALTER TABLE `workshop_mcqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `workshop_results`
--
ALTER TABLE `workshop_results`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hiring_task`
--
ALTER TABLE `hiring_task`
  MODIFY `hiring_task_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `project`
--
ALTER TABLE `project`
  MODIFY `project_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `reward`
--
ALTER TABLE `reward`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `signin`
--
ALTER TABLE `signin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `sub_project`
--
ALTER TABLE `sub_project`
  MODIFY `sub_project_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `task`
--
ALTER TABLE `task`
  MODIFY `task_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `team`
--
ALTER TABLE `team`
  MODIFY `team_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user_reviews`
--
ALTER TABLE `user_reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_reward`
--
ALTER TABLE `user_reward`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `workshop`
--
ALTER TABLE `workshop`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `workshop_mcqs`
--
ALTER TABLE `workshop_mcqs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `workshop_results`
--
ALTER TABLE `workshop_results`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
